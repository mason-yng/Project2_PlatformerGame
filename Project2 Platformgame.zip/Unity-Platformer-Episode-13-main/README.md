# Unity-Platformer-Episode-13
In this episode we'll add checkpoints and the ability to respawn the player.
https://www.youtube.com/watch?v=STBVkS1Y3dk
